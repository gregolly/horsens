<?php
/**
 * Plugin Name:       Funcionalidades Personalizadas do Site
 * Description:       Registra os Custom Post Types (Equipe, Vantagens, etc.) e outras funcionalidades core.
 * Version:           1.0
 * Author:            Gregolly França
 */

// Acesso direto negado
if ( ! defined( 'ABSPATH' ) ) {
    exit; 
}

add_action( 'plugins_loaded', '_horsens_load_textdomain' );
function _horsens_load_textdomain() {
    load_plugin_textdomain( 'horsens', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}

// Função de ativação
register_activation_hook( __FILE__, '_horsens_activate' );
function _horsens_activate() {
    _horsens_cpt_equipe_register();
    _horsens_cpt_vantagens_register();
    flush_rewrite_rules();
}

// Função de desativação
register_deactivation_hook( __FILE__, '_horsens_deactivate' );
function _horsens_deactivate() {
    flush_rewrite_rules();
}

/**
 * Registra o Custom Post Type 'Equipe'.
 */
if (! function_exists('_horsens_cpt_equipe_register')) :
function _horsens_cpt_equipe_register() {
    $labels = array(
        'name'               => _x( 'Equipe', 'post type general name', 'horsens' ),
        'singular_name'      => _x( 'Membro', 'post type singular name', 'horsens' ),
        'add_new'            => _x( 'Adicionar Novo', 'equipe', 'horsens'),
        'add_new_item'       => __( 'Adicionar Novo Membro', 'horsens'),
        'edit_item'          => __( 'Editar Membro', 'horsens'),
        'new_item'           => __( 'Novo Membro', 'horsens'),
        'all_items'          => __( 'Todos os Membros', 'horsens'),
        'view_item'          => __( 'Ver Membro', 'horsens'),
        'search_items'       => __( 'Procurar Membros', 'horsens'),
        'not_found'          => __( 'Nenhum membro encontrado', 'horsens'),
        'not_found_in_trash' => __( 'Nenhum membro encontrado na lixeira', 'horsens'),
        'parent_item_colon'  => '',
        'menu_name'          => 'Equipe'
    );
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'equipe' ), // URL: /equipe/nome-do-membro
        'capability_type'    => 'post',
        'has_archive'        => true, // URL de arquivo: /equipe
        'hierarchical'       => false,
        'menu_position'      => 5,
        'menu_icon'          => 'dashicons-groups',
        'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'revisions' ),
        'show_in_rest'       => true, // Adicionar suporte ao Gutenberg
    );
    register_post_type( 'equipe', $args );
}
endif;
// Hook para registrar o CPT 'equipe'
add_action( 'init', '_horsens_cpt_equipe_register' );


/**
 * Registra o Custom Post Type 'Vantagens'.
 */
if (! function_exists('_horsens_cpt_vantagens_register')) :
function _horsens_cpt_vantagens_register() {
    $labels = array(
        'name'               => _x( 'Vantagens', 'post type general name', 'horsens'),
        'singular_name'      => _x( 'Vantagem', 'post type singular name', 'horsens'),
        'add_new'            => _x( 'Adicionar Nova', 'vantagem', 'horsens'),
        'add_new_item'       => __( 'Adicionar Nova Vantagem', 'horsens'),
        'edit_item'          => __( 'Editar Vantagem', 'horsens'),
        'new_item'           => __( 'Nova Vantagem', 'horsens'),
        'all_items'          => __( 'Todas as Vantagens', 'horsens'),
        'view_item'          => __( 'Ver Vantagem', 'horsens'),
        'search_items'       => __( 'Procurar Vantagens', 'horsens'),
        'not_found'          => __( 'Nenhuma vantagem encontrada', 'horsens'),
        'not_found_in_trash' => __( 'Nenhuma vantagem encontrada na lixeira', 'horsens'),
        'parent_item_colon'  => '',
        'menu_name'          => 'Vantagens'
    );
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'vantagens' ), // URL: /vantagens/nome-da-vantagem
        'capability_type'    => 'post',
        'has_archive'        => true, // URL de arquivo: /vantagens
        'hierarchical'       => false,
        'menu_position'      => 6,
        'menu_icon'          => 'dashicons-star-filled',
        'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ), // Suporte básico
        'show_in_rest'       => true, // Adicionar suporte ao Gutenberg
    );
    register_post_type( 'vantagens', $args );
}
// Hook para registrar o CPT 'vantagens'
add_action( 'init', '_horsens_cpt_vantagens_register' );
endif;

?>
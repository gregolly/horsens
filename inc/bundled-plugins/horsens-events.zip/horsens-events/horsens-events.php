<?php
/*
Plugin Name: Horsens Eventos
Description: Sistema de gerenciamento de eventos e inscrições para a Horsens.
Version: 1.0
Author: Gregolly França
*/

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! defined( 'WPINC' ) ) die;


// Defina constantes para facilitar caminhos
define( 'HORSENS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Carregar as classes (Includes)
require_once HORSENS_PLUGIN_DIR . 'includes/class-horsens-cpt.php';
require_once HORSENS_PLUGIN_DIR . 'includes/class-horsens-metabox.php';
require_once HORSENS_PLUGIN_DIR . 'includes/class-horsens-shortcode.php';
require_once HORSENS_PLUGIN_DIR . 'includes/class-horsens-query.php';
require_once HORSENS_PLUGIN_DIR . 'includes/class-horsens-settings.php';

// Inicializar as Classes
function horsens_init_plugin() {
    new Horsens_Events_CPT();
    new Horsens_Events_Metabox();
    new Horsens_Events_Shortcode();
    new Horsens_Events_Query();
    new Horsens_register_settings();
}
add_action( 'plugins_loaded', 'horsens_init_plugin' );
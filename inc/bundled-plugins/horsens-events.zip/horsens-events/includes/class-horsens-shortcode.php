<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Horsens_Events_Shortcode {

    public function __construct() {
        add_shortcode( 'horsens_form_inscricao', array( $this, 'render_shortcode' ) );
    }

    public function render_shortcode() {
        // Proteção Admin
        if ( is_admin() || defined( 'REST_REQUEST' ) ) {
            return '<div style="padding:10px; border:1px dashed #ccc;">Formulário Horsens (Frontend)</div>';
        }

        $evento_id = 0;
        $evento_titulo = '';
        $mensagem = '';

        $input_nome = isset($_POST['horsens_nome']) ? esc_attr($_POST['horsens_nome']) : '';
        $input_email = isset($_POST['horsens_email']) ? esc_attr($_POST['horsens_email']) : '';
        $input_phone = isset($_POST['horsens_phone']) ? esc_attr($_POST['horsens_phone']) : '';
        $input_cpf = isset($_POST['horsens_cpf']) ? esc_attr($_POST['horsens_cpf']) : '';
        
        // Detecção de Evento via GET
        if ( isset( $_GET['event_id'] ) ) {
            $evento_id = intval( $_GET['event_id'] );
            
            if ($evento_id > 0 && get_post_type($evento_id) === 'evento' && get_post_status($evento_id) === 'publish') {
                $evento_titulo = get_the_title( $evento_id );
            } else {
                $evento_id = 0; 
            }
        }

        // Processar envio do formulário
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' && isset( $_POST['horsens_nonce'] ) ) {
            if ( ! isset( $_POST['horsens_nonce'] ) || ! wp_verify_nonce( $_POST['horsens_nonce'], 'horsens_inscricao_nonce' ) ) {
                $mensagem = '<div class="mb-6 p-4 text-sm font-sans bg-red-50 border-l-4 border-red-500 text-red-700">Erro de segurança. Tente novamente.</div>';
            } else {
                $evento_id_selecionado = isset($_POST['horsens_evento_selecionado']) ? intval($_POST['horsens_evento_selecionado']) : 0;

                if ($evento_id_selecionado > 0 && get_post_type($evento_id_selecionado) === 'evento' && get_post_status($evento_id_selecionado) === 'publish') {
                    $evento_id = $evento_id_selecionado;
                    $evento_titulo = get_the_title($evento_id);
                    $mensagem = $this->processar_inscricao( $evento_id, $evento_titulo );
                } else {
                    $mensagem = '<div class="mb-6 p-4 text-sm font-sans bg-red-50 border-l-4 border-red-500 text-red-700">Erro: Por favor, selecione um evento válido.</div>';
                }
            }
        }

        // --- INÍCIO DA RENDERIZAÇÃO ---
        ob_start();
        ?>
        <div class="horsens-form-wrap w-full max-w-2xl mx-auto my-16 bg-white p-8 md:p-12 shadow-md border border-brand-azul-escuro/10 rounded-sm mt-10 mb-10">
            
            <?php if ($mensagem) echo $mensagem; ?>
            
            <form method="post" action="<?php echo esc_url( remove_query_arg( 'submitted' ) ); ?>">
                <?php wp_nonce_field( 'horsens_inscricao_nonce', 'horsens_nonce' ); ?>
                
                <div class="mb-10 border-b border-brand-azul-escuro/10 pb-6">
                    <?php if ( $evento_id > 0 ) : ?>
                        <h3 class="font-serif text-3xl text-brand-azul-escuro mt-0 mb-2 leading-tight">
                            Inscrição para: <span class="text-brand-marrom"><?php echo esc_html($evento_titulo); ?></span>
                        </h3>
                        <p class="text-sm font-sans text-brand-azul-escuro/60">Preencha seus dados abaixo para garantir sua vaga.</p>
                    <?php else : ?>
                        <label for="horsens_evento_selecionado_select" class="block font-serif text-2xl text-brand-azul-escuro mb-2">
                            Selecione um Evento:
                        </label>
                        <div class="relative">
                            <select name="horsens_evento_selecionado" id="horsens_evento_selecionado_select" required 
                                    class="block w-full appearance-none bg-transparent border-b-2 border-brand-cafe/20 px-0 py-3 text-brand-azul-escuro font-sans focus:border-brand-marrom focus:outline-none focus:ring-0 transition-colors text-lg">
                                <option value="">-- Escolha um evento --</option>
                                <?php
                                $eventos = get_posts(array(
                                    'post_type' => 'evento', 
                                    'numberposts' => 500,
                                    'post_status' => 'publish',
                                    'meta_key' => '_horsens_data',
                                    'orderby' => 'meta_value',
                                    'order' => 'ASC',
                                    'fields' => 'ids'
                                ));
                                
                                foreach ($eventos as $ev_id) {
                                    $ev_titulo = get_the_title($ev_id);
                                    $ev_data = get_post_meta($ev_id, '_horsens_data', true);
                                    $display_date = $ev_data ? date_i18n('d/m/Y', strtotime($ev_data)) : 'Data não definida';
                                    echo '<option value="' . esc_attr($ev_id) . '">' . esc_html($ev_titulo) . ' (' . $display_date . ')</option>';
                                }
                                ?>
                            </select>
                            <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-brand-marrom">
                                <svg class="h-5 w-5 fill-current" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- form da inscricao -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
                    
                    <div class="md:col-span-2">
                        <label for="horsens_nome" class="block text-xs font-bold uppercase tracking-widest text-brand-azul-escuro/60 mb-2">Nome Completo</label>
                        <input type="text" name="horsens_nome" id="horsens_nome" 
                                value="<?php echo $input_nome; ?>"
                                class="w-full bg-white border border-brand-azul-escuro/20 px-4 py-4 text-brand-azul-escuro font-sans focus:border-brand-marrom focus:outline-none focus:ring-1 focus:ring-brand-marrom transition-all placeholder-brand-azul-escuro/30"
                                placeholder="Digite seu nome">
                        <?php 
                            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                if (empty($_POST['horsens_nome'])) {
                                    echo '<div class="horsens-error font-sans" style="color:red; margin-top:5px; font-size: 0.875rem;">O campo Nome é obrigatório.</div>';
                                } elseif(strlen( $nome ) > 100) {
                                    echo '<div class="horsens-error font-sans">Nome muito longo (máx. 100 caracteres)</div>';
                                }
                            }
                        ?>
                    </div>

                    <div class="md:col-span-2">
                        <label for="horsens_email" class="block text-xs font-bold uppercase tracking-widest text-brand-azul-escuro/60 mb-2">E-mail</label>
                        <input type="email" name="horsens_email" id="horsens_email" 
                                value="<?php echo $input_email; ?>"
                                class="w-full bg-white border border-brand-azul-escuro/20 px-4 py-4 text-brand-azul-escuro font-sans focus:border-brand-marrom focus:outline-none focus:ring-1 focus:ring-brand-marrom transition-all placeholder-brand-azul-escuro/30"
                                placeholder="seu@email.com">
                        <?php 

                            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                if (empty($_POST['horsens_email'])) {
                                    echo '<div class="horsens-error font-sans" style="color:red; margin-top:5px; font-size: 0.875rem;">O campo E-mail é obrigatório.</div>';
                                } elseif(! is_email( $email )) {
                                    echo '<div class="horsens-error font-sans" style="color:red; margin-bottom:15px; font-size: 0.875rem;">E-mail inválido.</div>';
                                }
                            }
                        ?>
                    </div>

                    <div class="md:col-span-2">
                        <label for="horsens_phone" class="block text-xs font-bold uppercase tracking-widest text-brand-azul-escuro/60 mb-2">Telefone</label>
                        <input type="text" name="horsens_phone" id="horsens_phone" 
                                value="<?php echo $input_phone; ?>"
                                class="w-full bg-white border border-brand-azul-escuro/20 px-4 py-4 text-brand-azul-escuro font-sans focus:border-brand-marrom focus:outline-none focus:ring-1 focus:ring-brand-marrom transition-all placeholder-brand-azul-escuro/30"
                                placeholder="(00) 00000-0000">
                        <?php 
                            if (empty($_POST['horsens_phone']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
                                echo '<div class="horsens-error font-sans" style="color:red; margin-top:5px; font-size: 0.875rem;">O campo Telefone é obrigatório.</div>';
                            }
                        ?>
                    </div>

                    <div class="md:col-span-2">
                        <label for="horsens_cpf" class="block text-xs font-bold uppercase tracking-widest text-brand-azul-escuro/60 mb-2">CPF</label>
                        <input type="text" name="horsens_cpf" id="horsens_cpf" 
                                value="<?php echo $input_cpf; ?>"
                                class="w-full bg-white border border-brand-azul-escuro/20 px-4 py-4 text-brand-azul-escuro font-sans focus:border-brand-marrom focus:outline-none focus:ring-1 focus:ring-brand-marrom transition-all placeholder-brand-azul-escuro/30"
                                placeholder="000.000.000-00">
                        <?php 
                            // Lógica de validação INLINE do CPF
                            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                if (empty($_POST['horsens_cpf'])) {
                                    echo '<div class="horsens-error font-sans" style="color:red; margin-top:5px; font-size: 0.875rem;">O campo CPF é obrigatório.</div>';
                                } elseif (! $this->validar_cpf($_POST['horsens_cpf'])) {
                                    echo '<div class="horsens-error font-sans" style="color:red; margin-top:5px; font-size: 0.875rem;">CPF inválido. Verifique se digitou corretamente.</div>';
                                }
                            }
                        ?>
                    </div>

                </div>

                <!-- Botão de Envio com Loader -->
                <button type="submit" name="horsens_submit" id="btn_submit_horsens"
                    class="w-full h-12 flex items-center justify-center cursor-pointer bg-brand-marrom text-white font-sans font-bold uppercase tracking-widest hover:bg-brand-azul-escuro transition-colors duration-300 shadow-md text-lg disabled:opacity-75 disabled:cursor-not-allowed">
                    
                    <!-- Estado Normal -->
                    <span id="btn_text_normal">Garantir Vaga</span>
                    
                    <!-- Estado Carregando (Escondido por padrão) -->
                    <span id="btn_text_loading" class="hidden flex items-center">
                        <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Processando...
                    </span>
                </button>
                
                <input type="hidden" name="horsens_evento_selecionado" value="<?php echo esc_attr($evento_id); ?>">
            </form>
        </div>

        <!-- SCRIPT PARA FEEDBACK VISUAL (Adicionado) -->
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            var form = document.querySelector('.horsens-form-wrap form');
            var btn = document.getElementById('btn_submit_horsens');
            var txtNormal = document.getElementById('btn_text_normal');
            var txtLoading = document.getElementById('btn_text_loading');

            if(form && btn) {
                form.addEventListener('submit', function(e) {
                    if (form.checkValidity()) {
                        btn.disabled = true;
                        btn.classList.add('opacity-75', 'cursor-not-allowed');
                        
                        if(txtNormal) txtNormal.style.display = 'none';
                        if(txtLoading) txtLoading.classList.remove('hidden');
                    }
                });
            }
        });
        </script>
        <?php
        return ob_get_clean();
    }

    // Método auxiliar de validação de CPF
    private function validar_cpf( $cpf ) {
        $cpf = preg_replace( '/[^0-9]/', '', $cpf );
        
        if ( strlen( $cpf ) != 11 ) {
            return false;
        }
        
        return true;
    }
        
    private function processar_inscricao( $evento_id, $evento_titulo ) {
        if ( empty($_POST['horsens_nome']) || empty($_POST['horsens_email']) || empty($_POST['horsens_phone']) || empty($_POST['horsens_cpf']) ) {
            return '';
        }

        $nome = sanitize_text_field( $_POST['horsens_nome'] );
        $email = sanitize_email( $_POST['horsens_email'] );
        $phone = sanitize_text_field( $_POST['horsens_phone'] );
        $cpf = sanitize_text_field( $_POST['horsens_cpf'] );

        if ( strlen( $nome ) > 100 ) {
            return '';
        }

        // Validação de E-mail
        if ( ! is_email( $email ) ) {
            return '';
        }

        // Validação de CPF
        if ( ! $this->validar_cpf( $cpf ) ) {
            return '';
        }
        
        // 📌 1. VERIFICAÇÃO DE DUPLICIDADE 
        $inscricoes_existentes = get_posts(array(
            'post_type' => 'horsens_inscricao',
            'meta_query' => array(
                'relation' => 'AND',
                array('key' => '_horsens_evento_id', 'value' => $evento_id),
                array('key' => '_horsens_email', 'value' => $email)
            ),
            'fields' => 'ids', // Otimiza a busca, só precisamos saber se existe
            'posts_per_page' => 1
        ));

        // BLOQUEIA a inscrição se já existir
        if ( ! empty( $inscricoes_existentes ) ) {
            return '<div class="horsens-warning" style="color:black; margin-bottom:15px;">⚠️ Você já está inscrito neste evento. Não é permitido um novo cadastro.</div>';
        }
        
        /// --- CRIA NOVO REGISTRO ---
        $inscricao_id = wp_insert_post( array(
            'post_type' => 'horsens_inscricao',
            'post_title' => $nome . ' (' . $evento_titulo . ')',
            'post_status' => 'publish'
        ));

        // URL da página de agradecimento
        $slug_agradecimento = get_option( 'horsens_url_agradecimento', '/agradecimento-8wpn-fvvr7yl94' );
        $url_agradecimento = site_url('/agradecimento-8wpn-fvvr7yl94');

        if ( ! is_wp_error( $inscricao_id ) && $inscricao_id > 0 ) {
            update_post_meta( $inscricao_id, '_horsens_evento_id', $evento_id );
            update_post_meta( $inscricao_id, '_horsens_email', $email );
            update_post_meta( $inscricao_id, '_horsens_nome', $nome );
            update_post_meta( $inscricao_id, '_horsens_phone', $phone );
            update_post_meta( $inscricao_id, '_horsens_cpf', $cpf );
            update_post_meta( $inscricao_id, '_horsens_data_inscricao', current_time('mysql') );
            
            // Limpar os campos do formulário após sucesso
            unset($_POST);
            
            return '<script>window.location.href = "' . esc_url($url_agradecimento) . '";</script>';
        }
        
        return '<div class="horsens-error" style="color:red; margin-bottom:15px;">Erro ao processar inscrição. Tente novamente.</div>';
    }
}
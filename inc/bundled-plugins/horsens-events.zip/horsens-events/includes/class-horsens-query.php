<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Horsens_Events_Query {

    public function __construct() {
        add_action( 'pre_get_posts', array( $this, 'order_events' ) );
    }

    public function order_events( $query ) {
        if ( ! is_admin() && $query->is_main_query() && is_post_type_archive( 'evento' ) ) {
            $query->set( 'meta_query', array(
                array(
                    'key' => '_horsens_data',
                    'compare' => 'EXISTS', // Garante que só ordene posts que têm a data
                )
            ) );
            $query->set( 'meta_key', '_horsens_data' );
            $query->set( 'orderby', 'meta_value' );
            $query->set( 'order', 'ASC' );

            if (!$query->get( 'posts_per_page' ) ) {
                $query->set( 'posts_per_page', 10 );
            }
        }
    }
}
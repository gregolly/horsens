<?php
/**
 * Adiciona o campo de URL de Agradecimento nas Configurações Gerais do WP
 */
class Horsens_register_settings {
    // Registra a configuração no banco de dados
    public function __construct() {
        add_action('admin_init', array($this, 'register_fields'));
    }
    
    // Adiciona o campo na seção "Geral"
    public function register_fields() {
        // 1. Registra a configuração no banco de dados
        register_setting('general', 'horsens_url_agradecimento');
        
        // 2. Adiciona o campo na seção "Geral"
        add_settings_field(
            'horsens_url_agradecimento',         // ID do campo
            'Página de Agradecimento (Eventos)', // Título que aparece na tela
            array($this, 'horsens_url_agradecimento_html'), // Chama o método da classe para desenhar o input
            'general',                           // Página onde aparece (Configurações > Geral)
            'default'                            // Seção da página
        );
    }

    public function horsens_url_agradecimento_html() {
        $value = get_option('horsens_url_agradecimento', '/agradecimento-8wpn-fvvr7yl94');
        ?>
        <input type="text" name="horsens_url_agradecimento" value="<?php echo esc_attr($value); ?>" class="regular-text">
        <p class="description">Digite o slug da página para onde o usuário será redirecionado após se inscrever (ex: <code>/obrigado</code> ou <code>/confirmacao</code>).</p>
        <?php
    }
}



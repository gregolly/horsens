<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Horsens_Events_Metabox {

    public function __construct() {
        add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
        add_action( 'save_post', array( $this, 'save_meta_box' ) );
    }

    public function add_meta_boxes() {
        add_meta_box(
            'horsens_evento_meta',
            'Dados do Evento',
            array( $this, 'render_metabox' ),
            'evento',
            'normal',
            'high'
        );

        add_meta_box(
            'horsens_participantes_meta',
            '👥 Participantes Inscritos', // Título para a caixa
            array( $this, 'render_participantes_metabox' ), // Novo método de callback
            'evento',
            'normal',
            'low'
        );

        add_meta_box(
            'horsens_inscrito_edit_meta',
            'Detalhes do Participante',
            array( $this, 'render_inscricao_edit_metabox' ), // Novo callback
            'horsens_inscricao', // 📌 ATENÇÃO: Target no CPT de INSCRIÇÃO
            'normal',
            'high'
        );
    }

    public function render_metabox( $post ) {
        // Recuperando com o novo prefixo
        $data = get_post_meta( $post->ID, '_horsens_data', true );
        $local = get_post_meta( $post->ID, '_horsens_local', true );
        $duracao = get_post_meta( $post->ID, '_horsens_duracao', true );
        ?>

        <p>
            <label><strong>Data do Evento:</strong></label><br>
            <input type="date" name="horsens_data" value="<?php echo esc_attr( $data ); ?>" style="width:100%">
        </p>

        <p>
            <label><strong>Localização:</strong></label><br>
            <input type="text" name="horsens_local" value="<?php echo esc_attr( $local ); ?>" style="width:100%">
        </p>

        <p>
            <label><strong>Duração:</strong></label><br>
            <input type="text" name="horsens_duracao" value="<?php echo esc_attr( $duracao ); ?>" style="width:100%">
        </p>
        <?php
    }

    /**
     * Renderiza a lista de inscritos para o evento atual
     */
    public function render_participantes_metabox( $post ) {
        $event_id = $post->ID;

        // Consulta que busca todas as inscrições que apontam para este evento
        $participantes_query = new WP_Query([
            'post_type'  => 'horsens_inscricao', // CPT de Inscrições
            'meta_key'   => '_horsens_evento_id', // Chave de relacionamento
            'meta_value' => $event_id, // ID do evento atual
            'posts_per_page' => -1, // Traz todos os inscritos
            'order'      => 'ASC'
        ]);

        if ( $participantes_query->have_posts() ) {
            $count = $participantes_query->found_posts;
            echo '<p>Total de Inscritos: <strong>' . $count . '</strong></p>';
            
            echo '<table class="wp-list-table widefat fixed striped">';
            echo '<thead><tr><th>Nome</th><th>Email</th><th>Data da Inscrição</th></tr></thead>';
            echo '<tbody>';

            while ( $participantes_query->have_posts() ) {
                $participantes_query->the_post();
                
                $nome = get_the_title();
                $email = get_post_meta( get_the_ID(), '_horsens_email', true );
                $data_inscricao = get_the_date( 'd/m/Y H:i' );

                echo '<tr>';
                echo '<td>' . esc_html( $nome ) . '</td>';
                echo '<td>' . esc_html( $email ) . '</td>';
                echo '<td>' . esc_html( $data_inscricao ) . '</td>';
                echo '</tr>';
            }

            echo '</tbody></table>';
            
            // 📌 ESSENCIAL: Resetar os dados do post para evitar bugs no admin
            wp_reset_postdata(); 

        } else {
            echo '<p>Ainda não há inscritos confirmados para este evento.</p>';
        }
    }

    // Dentro da classe Horsens_Events_Metabox
    public function render_inscricao_edit_metabox( $post ) {
        $nome = get_post_meta( $post->ID, '_horsens_nome', true );
        $email = get_post_meta( $post->ID, '_horsens_email', true );
        $phone = get_post_meta( $post->ID, '_horsens_phone', true );
        $cpf = get_post_meta( $post->ID, '_horsens_cpf', true );
        $event_id = get_post_meta( $post->ID, '_horsens_evento_id', true );
        $event_title = get_the_title( $event_id );
        ?>
        
        <p>
            <strong>Evento Relacionado:</strong> 
            <a href="<?php echo get_edit_post_link($event_id); ?>" target="_blank">
                <?php echo esc_html($event_title); ?>
            </a>
        </p>

        <p>
            <label for="horsens_nome_inscrito">Nome do Participante:</label><br>
            <input type="text" name="horsens_nome_inscrito" id="horsens_nome_inscrito" value="<?php echo esc_attr($nome); ?>" style="width:100%">
        </p>
        <p>
            <label for="horsens_email_inscrito">E-mail do Participante:</label><br>
            <input type="email" name="horsens_email_inscrito" id="horsens_email_inscrito" value="<?php echo esc_attr($email); ?>" style="width:100%">
        </p>
        <p>
            <label for="horsens_telefone_inscrito">Telefone do Participante:</label><br>
            <input type="text" name="horsens_telefone_inscrito" id="horsens_telefone_inscrito" value="<?php echo esc_attr($phone); ?>" style="width:100%">
        </p>
        <p>
            <label for="horsens_cpf_inscrito">CPF do Participante:</label><br>
            <input type="text" name="horsens_cpf_inscrito" id="horsens_cpf_inscrito" value="<?php echo esc_attr($cpf); ?>" style="width:100%">
        </p>
        <?php
    }

    // Dentro da classe Horsens_Events_Metabox
    public function save_meta_box( $post_id ) {
        // Verifica auto-save, AJAX e permissões
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
        if ( wp_is_post_revision( $post_id ) ) return;

        // Verifica nonce para segurança
        if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'update-post_' . $post_id ) ) {
            return;
        }
        
        // 1. LÓGICA DE SALVAMENTO DE INSCRITOS
        if ( get_post_type($post_id) == 'horsens_inscricao' ) {
            // Salvando os metadados
            if ( isset($_POST['horsens_nome_inscrito']) ) {
                $novo_nome = sanitize_text_field($_POST['horsens_nome_inscrito']);
                $nome_antigo = get_post_meta($post_id, '_horsens_nome', true);
                
                update_post_meta($post_id, '_horsens_nome', $novo_nome);
            }

            if ( isset($_POST['horsens_email_inscrito']) ) {
                update_post_meta($post_id, '_horsens_email', sanitize_email($_POST['horsens_email_inscrito']));
            }

            if (isset($_POST['horsens_telefone_inscrito'])) {
                update_post_meta($post_id, '_horsens_phone', sanitize_text_field($_POST['horsens_telefone_inscrito']));
            }

            if ( isset($_POST['horsens_cpf_inscrito']) ) {
                update_post_meta($post_id, '_horsens_cpf', sanitize_text_field($_POST['horsens_cpf_inscrito']));
            }

            // 📌 CORREÇÃO DE RECURSÃO: Atualizar o Título do Post (se o nome mudou)
            if ( isset($novo_nome) && $novo_nome != $nome_antigo ) {
                
                // 🛑 PASSO CRÍTICO: REMOVE A AÇÃO DE SALVAR TEMPORARIAMENTE
                remove_action( 'save_post', array( $this, 'save_meta_box' ) );

                // Atualiza o post (só acontece se o nome do inscrito mudou)
                wp_update_post(array(
                    'ID' => $post_id,
                    'post_title' => $novo_nome . ' (' . $evento_titulo . ')',
                ));

                // ✅ RESTAURA A AÇÃO DE SALVAR
                add_action( 'save_post', array( $this, 'save_meta_box' ) );
            }

            return; // Termina a função aqui para posts de inscrição
        }

        // 2. LÓGICA DE SALVAMENTO DE EVENTOS (Se o post_type for 'evento')
        if ( isset($_POST['horsens_data']) ) {
            update_post_meta( $post_id, '_horsens_data', sanitize_text_field( $_POST['horsens_data'] ) );
        }
        if ( isset($_POST['horsens_local']) ) {
            update_post_meta( $post_id, '_horsens_local', sanitize_text_field( $_POST['horsens_local'] ) );
        }
        if ( isset($_POST['horsens_duracao']) ) {
            update_post_meta( $post_id, '_horsens_duracao', sanitize_text_field( $_POST['horsens_duracao'] ) );
        }
    }
}
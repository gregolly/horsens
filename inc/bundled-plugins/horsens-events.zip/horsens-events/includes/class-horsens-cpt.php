<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Horsens_Events_CPT {

    public function __construct() {
        add_action( 'init', array( $this, 'register_cpts' ) );
    }

    public function register_cpts() {
        // Eventos
        register_post_type('evento', array(
            'labels'      => array('name' => 'Eventos Horsens', 'singular_name' => 'Evento'),
            'public'      => true,
            'has_archive' => true,
            'supports'    => array('title', 'editor', 'thumbnail', 'excerpt'),
            'taxonomies'  => array('category', 'post_tag'),
            'rewrite'     => array('slug' => 'evento'),
            'show_in_rest'=> true,
            'menu_icon'   => 'dashicons-calendar-alt',
        ));

        // Inscrições
        register_post_type('horsens_inscricao', array(
            'labels'      => array('name' => 'Inscrições', 'singular_name' => 'Inscrição'),
            'public'      => false,
            'show_ui'     => true,
            'supports'    => array('title'),
            'menu_icon'   => 'dashicons-groups',
            'query_var'   => false,
            'rewrite'     => false,
        ));
    }
}